# -*- coding:utf-8 -*-
#查询按钮名称变量定义
HLD_SEL_BTN='账户持有查询'
HLD_NZ_BTN='账户非零查询'