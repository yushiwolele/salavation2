# -*- coding:utf-8 -*-
#技术测试环境
DICT__TEST = {
    "支撑平台门户路径":'https://ark.cdsc.com',
    "用户名":'sctestljjcsdc',
    "密码":'Manager12345678'
}