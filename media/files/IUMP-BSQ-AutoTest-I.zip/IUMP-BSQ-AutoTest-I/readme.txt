【Conf】存放环境配置变量文件，包括env.py、config.txt
